package com.example.basicauthdashboardapp.repository

import com.example.basicauthdashboardapp.data.RetrofitClient
import com.example.basicauthdashboardapp.model.User

class UserRepository {
    suspend fun getUsers(): List<User> {
        return RetrofitClient.apiService.getUsers()
    }
}