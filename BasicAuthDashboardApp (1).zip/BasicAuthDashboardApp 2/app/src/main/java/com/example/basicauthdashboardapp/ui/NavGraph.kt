package com.example.basicauthdashboardapp.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.basicauthdashboardapp.ui.dashboard.DashboardScreen
import com.example.basicauthdashboardapp.ui.forgotpassword.ForgotPasswordScreen
import com.example.basicauthdashboardapp.ui.login.LoginPage
import com.example.basicauthdashboardapp.ui.splash.SplashScreen

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = "splash") {
        composable("splash") {
            SplashScreen(navController)
        }
        composable("login") {
            LoginPage(navController)
        }
        composable("forgot_password") {
            ForgotPasswordScreen(navController)
        }
        composable("dashboard") {
            DashboardScreen()
        }
    }
}
