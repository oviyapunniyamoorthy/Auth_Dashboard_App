package com.example.basicauthdashboardapp.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme
val md_theme_light_primary = Color(0xFF6A1B9A)       // Deep Purple
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_primaryContainer = Color(0xFFE1BEE7)
val md_theme_light_onPrimaryContainer = Color(0xFF1A0033)

// Dark Theme
val md_theme_dark_primary = Color(0xFFCE93D8)
val md_theme_dark_onPrimary = Color(0xFF000000)
val md_theme_dark_primaryContainer = Color(0xFF4A0072)
val md_theme_dark_onPrimaryContainer = Color(0xFFFFFFFF)