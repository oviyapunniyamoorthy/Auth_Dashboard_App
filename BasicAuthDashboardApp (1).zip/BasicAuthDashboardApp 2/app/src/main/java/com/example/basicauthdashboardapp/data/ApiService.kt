package com.example.basicauthdashboardapp.data

import com.example.basicauthdashboardapp.model.User
import retrofit2.http.GET

interface ApiService {
    @GET("users")
    suspend fun getUsers(): List<User>
}